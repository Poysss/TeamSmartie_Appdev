package com.appdev.bagarinao.review.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appdev.bagarinao.review.entity.ReviewEntity;
import com.appdev.bagarinao.review.service.ReviewService;


@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/review")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @PostMapping("/save")
    public ReviewEntity saveReview(@RequestBody ReviewEntity review) {
        return reviewService.saveReview(review);
    }

    @GetMapping("/getAll")
    public List<ReviewEntity> getAllReviews() {
        return reviewService.getAllReview();
    }

    @DeleteMapping("/delete/{reviewID}")
    public String deleteReview(@PathVariable int reviewID) {
        return reviewService.deleteReview(reviewID);
    }

    @PutMapping("/update")
    public ReviewEntity updateReview(@RequestParam int reviewID, @RequestBody ReviewEntity review) {
        return reviewService.updateReview(reviewID, review);
    }
}

package com.appdev.bagarinao.review.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appdev.bagarinao.review.entity.ProgressEntity;
import com.appdev.bagarinao.review.service.ProgressService;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/progress")
public class ProgressController {

    @Autowired
    private ProgressService progressService;

    // Create Progress
    @PostMapping("/save")
    public ResponseEntity<ProgressEntity> saveProgress(@RequestBody ProgressEntity progress) {
        ProgressEntity savedProgress = progressService.saveProgress(progress);
        return new ResponseEntity<>(savedProgress, HttpStatus.CREATED);
    }

    // Get All Progress
    @GetMapping("/getAll")
    public ResponseEntity<List<ProgressEntity>> getAllProgress() {
        List<ProgressEntity> progressList = progressService.getAllProgress();
        return new ResponseEntity<>(progressList, HttpStatus.OK);
    }

    // Get Progress by ID
    @GetMapping("/{progressID}")
    public ResponseEntity<?> getProgressByID(@PathVariable int progressID) {
        try {
            ProgressEntity progress = progressService.getProgressByID(progressID);
            return new ResponseEntity<>(progress, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Update Progress
    @PutMapping("/update")
    public ResponseEntity<?> updateProgress(@RequestParam int progressID, @RequestBody ProgressEntity progress) {
        try {
            ProgressEntity updatedProgress = progressService.updateProgress(progressID, progress);
            return new ResponseEntity<>(updatedProgress, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }

    // Delete Progress
    @DeleteMapping("/delete/{progressID}")
    public ResponseEntity<String> deleteProgress(@PathVariable int progressID) {
        try {
            String responseMessage = progressService.deleteProgress(progressID);
            return new ResponseEntity<>(responseMessage, HttpStatus.OK);
        } catch (NoSuchElementException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}

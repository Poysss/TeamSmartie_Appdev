package com.appdev.bagarinao.review.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appdev.bagarinao.review.entity.ProgressEntity;
import com.appdev.bagarinao.review.repository.ProgressRepository;

@Service
public class ProgressService {

    @Autowired
    private ProgressRepository progressRepo;

    // Create
    public ProgressEntity saveProgress(ProgressEntity progress) {
        return progressRepo.save(progress);
    }

    // Get all
    public List<ProgressEntity> getAllProgress() {
        return progressRepo.findAll();
    }

    // Get by ID
    public ProgressEntity getProgressByID(int id) {
        return progressRepo.findById(id)
                           .orElseThrow(() -> new NoSuchElementException("Progress with ID " + id + " not found."));
    }

    // Update
    public ProgressEntity updateProgress(int progressID, ProgressEntity updatedProgress) {
        ProgressEntity progressEntity = progressRepo.findById(progressID)
                                                    .orElseThrow(() -> new NoSuchElementException("Progress with ID " + progressID + " not found."));
        progressEntity.setFlashCardID(updatedProgress.getFlashCardID());
        progressEntity.setScore(updatedProgress.getScore());
        progressEntity.setPerfectScore(updatedProgress.getPerfectScore());
        progressEntity.setTimeSpent(updatedProgress.getTimeSpent());

        return progressRepo.save(progressEntity);
    }

    // Delete
    public String deleteProgress(int progressID) {
        if (progressRepo.existsById(progressID)) {
            progressRepo.deleteById(progressID);
            return "Progress deleted successfully";
        } else {
            throw new NoSuchElementException("Progress with ID " + progressID + " not found.");
        }
    }
}

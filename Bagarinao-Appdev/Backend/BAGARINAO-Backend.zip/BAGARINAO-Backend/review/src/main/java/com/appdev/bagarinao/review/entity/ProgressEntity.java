package com.appdev.bagarinao.review.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "progress")
public class ProgressEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int progressID;
    private int flashCardID;
    private int score;
    private int perfectScore;
    private int timeSpent;

    public ProgressEntity(){}

    public ProgressEntity(int progressID, int flashCardID, int score, int perfectScore, int timeSpent){
        this.progressID = progressID;
        this.flashCardID = flashCardID;
        this.score = score;
        this.perfectScore = perfectScore;
        this.timeSpent = timeSpent;
    }

// Getter and Setter for progressID
    public int getProgressID() {
        return progressID;
    }

    public void setProgressID(int progressID) {
        this.progressID = progressID;
    }

    // Getter and Setter for flashCardID
    public int getFlashCardID() {
        return flashCardID;
    }

    public void setFlashCardID(int flashCardID) {
        this.flashCardID = flashCardID;
    }

    // Getter and Setter for score
    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    // Getter and Setter for perfectScore
    public int getPerfectScore() {
        return perfectScore;
    }

    public void setPerfectScore(int perfectScore) {
        this.perfectScore = perfectScore;
    }

    // Getter and Setter for timeSpent
    public int getTimeSpent() {
        return timeSpent;
    }

    public void setTimeSpent(int timeSpent) {
        this.timeSpent = timeSpent;
    }
}

package com.appdev.bagarinao.review.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.appdev.bagarinao.review.entity.ReviewEntity;
import com.appdev.bagarinao.review.repository.ReviewRepository;

@Service
public class ReviewService {

    @Autowired
    private ReviewRepository reviewRepo;

    // Create
    public ReviewEntity saveReview(ReviewEntity review) {
        return reviewRepo.save(review);
    }

    // Get all
    public List<ReviewEntity> getAllReview() {
        return reviewRepo.findAll();
    }

    // Get by ID
    public ReviewEntity getReviewByID(int id) {
        return reviewRepo.findById(id)
                         .orElseThrow(() -> new NoSuchElementException("Review with ID " + id + " not found."));
    }

    // Update
    public ReviewEntity updateReview(int reviewID, ReviewEntity updatedReview) {
        ReviewEntity reviewEntity = reviewRepo.findById(reviewID)
                                               .orElseThrow(() -> new NoSuchElementException("Review with ID " + reviewID + " not found."));
        reviewEntity.setFlashCardID(updatedReview.getFlashCardID());
        reviewEntity.setReviewIncorrectScore(updatedReview.getReviewIncorrectScore());
        reviewEntity.setReviewCorrectScore(updatedReview.getReviewCorrectScore());

        return reviewRepo.save(reviewEntity);
    }

    // Delete
    public String deleteReview(int reviewID) {
        if (reviewRepo.existsById(reviewID)) {
            reviewRepo.deleteById(reviewID);
            return "Data deleted successfully";
        } else {
            return "Review with ID " + reviewID + " not found!";
        }
    }
}

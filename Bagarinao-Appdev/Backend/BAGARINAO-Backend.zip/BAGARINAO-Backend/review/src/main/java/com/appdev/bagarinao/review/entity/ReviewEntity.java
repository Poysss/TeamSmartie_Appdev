package com.appdev.bagarinao.review.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "review")
public class ReviewEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reviewID")
    private int reviewID;

    @Column(name = "flashCardID", nullable = false)
    private int flashCardID;

    @Column(name = "reviewIncorrectScore", nullable = false)
    private int reviewIncorrectScore;

    @Column(name = "reviewCorrectScore", nullable = false)
    private int reviewCorrectScore;

    public ReviewEntity() {}

    public ReviewEntity(int flashCardID, int reviewIncorrectScore, int reviewCorrectScore) {
        this.flashCardID = flashCardID;
        this.reviewIncorrectScore = reviewIncorrectScore;
        this.reviewCorrectScore = reviewCorrectScore;
    }

    // Getters and setters
    public int getReviewID() { return reviewID; }
    public void setReviewID(int reviewID) { this.reviewID = reviewID; }

    public int getFlashCardID() { return flashCardID; }
    public void setFlashCardID(int flashCardID) { this.flashCardID = flashCardID; }

    public int getReviewIncorrectScore() { return reviewIncorrectScore; }
    public void setReviewIncorrectScore(int reviewIncorrectScore) { this.reviewIncorrectScore = reviewIncorrectScore; }

    public int getReviewCorrectScore() { return reviewCorrectScore; }
    public void setReviewCorrectScore(int reviewCorrectScore) { this.reviewCorrectScore = reviewCorrectScore; }
}

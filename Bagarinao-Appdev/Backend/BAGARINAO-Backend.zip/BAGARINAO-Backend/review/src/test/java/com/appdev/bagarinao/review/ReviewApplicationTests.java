package com.appdev.bagarinao.review;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
